<div>
    <x-links.danger class="cursor-pointer" wire:click="deleteReply">
        {{ __('Delete') }}
    </x-links.danger>
</div>
