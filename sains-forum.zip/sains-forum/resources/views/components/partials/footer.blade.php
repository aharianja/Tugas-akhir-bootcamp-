<footer class="p-8 bg-red-400">
    <div class="text-white wrapper">
        <span>
            &copy Copyright 2023 Kita Pintar
        </span>
    </div>
</footer>
